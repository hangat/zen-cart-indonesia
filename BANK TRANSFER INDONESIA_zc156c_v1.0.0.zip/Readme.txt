15 Transfer Modules of Popular Banks in Indonesia
modify from Direct Bank Deposit module by OZ_Jack & DrByte
---------

Install:

Extract into the root of your local site folders.
Upload via FTP or whatever you use.

Go to Admin Panel->Modules->Payment->[BANK_BCA, etc.]->Install!

Your done! Just type in your details shown.



